package com.example.upin.aplikasipemesananhoteldibandarlampung;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class PesanKamar extends AppCompatActivity {

    private static final String TAG_NAMA = "Nama Hotel";
    private static final String TAG_LOKASI = "Lokasi";
    private static final String TAG_HARGA = "Harga";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesan_kamar);

        Intent in = getIntent();

        String nama = in.getStringExtra(TAG_NAMA);
        String lokasi = in.getStringExtra(TAG_LOKASI);
        final String harga = in.getStringExtra(TAG_HARGA);
        final String namacustomer = in.getStringExtra("nama");
        final String alamatcustomer = in.getStringExtra("alamat");
        final String notelpcustomer = in.getStringExtra("notelp");

        TextView lblNama = (TextView) findViewById(R.id.nama);
        TextView lblLokasi = (TextView) findViewById(R.id.lokasi);
        TextView lblHarga = (TextView) findViewById(R.id.harga);
        final EditText jmlkamar = (EditText)findViewById(R.id.editTextJmlKamar);
        final EditText lamabermalam = (EditText)findViewById(R.id.editTextLamaBermalam);
        Button cetak = (Button)findViewById(R.id.cetakstruk);

        lblNama.setText(nama);
        lblLokasi.setText(lokasi);
        lblHarga.setText(harga+"/kamar");

        cetak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getApplicationContext(),Struk.class);
                in.putExtra(TAG_HARGA, harga);
                in.putExtra("jmlkamar", jmlkamar.getText().toString());
                in.putExtra("lamabermalam", lamabermalam.getText().toString());
                in.putExtra("nama", namacustomer);
                in.putExtra("alamat", alamatcustomer);
                in.putExtra("notelp", notelpcustomer);
                startActivity(in);
            }
        });
    }
}
