package com.example.upin.aplikasipemesananhoteldibandarlampung;

import android.content.Intent;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.app.AlertDialog;

public class Struk extends AppCompatActivity {


    private static final String TAG_HARGA = "Harga";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_struk);

        Intent in = getIntent();

        String nama = in.getStringExtra("nama");
        String alamat = in.getStringExtra("alamat");
        String notelp = in.getStringExtra("notelp");
        String harga = in.getStringExtra(TAG_HARGA);
        String jmlkamar = in.getStringExtra("jmlkamar");
        String lamabermalam = in.getStringExtra("lamabermalam");

        TextView namacustomer = (TextView)findViewById(R.id.namacustomer);
        TextView alamatcustomer = (TextView)findViewById(R.id.alamatcustomer);
        TextView notelpcustomer = (TextView)findViewById(R.id.notelpcustomer);
        TextView kamar = (TextView)findViewById(R.id.jmlkamar);
        TextView bermalam = (TextView)findViewById(R.id.lamabermalam);
        TextView total = (TextView)findViewById(R.id.totalharga);
        Button keluar = (Button)findViewById(R.id.keluar);

        namacustomer.setText(nama);
        alamatcustomer.setText(alamat);
        notelpcustomer.setText(notelp);
        kamar.setText(jmlkamar);
        bermalam.setText(lamabermalam +" hari");

        int hrg = Integer.parseInt(harga.replaceAll("[\\D]", ""));
        int jmlkmr = Integer.parseInt(jmlkamar.replaceAll("[\\D]", ""));
        int brmlm = Integer.parseInt(lamabermalam.replaceAll("[\\D]", ""));
        int totalharga = hrg*jmlkmr*brmlm;

        total.setText("Total Harga : \nRp "+String.valueOf(totalharga));

        keluar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });


    }
    public void close() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Close").setMessage("Apakah anda ingin keluar?").setCancelable(false)
                .setPositiveButton("Ya",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                moveTaskToBack(true);
                            }
                        })
                .setNegativeButton("Tidak",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        }).show();
    }
}
