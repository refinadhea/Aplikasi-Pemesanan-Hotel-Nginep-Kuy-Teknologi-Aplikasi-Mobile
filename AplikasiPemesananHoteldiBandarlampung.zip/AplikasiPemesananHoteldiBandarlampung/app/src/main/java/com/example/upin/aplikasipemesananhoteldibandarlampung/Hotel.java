package com.example.upin.aplikasipemesananhoteldibandarlampung;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Hotel extends ListActivity {

    private ProgressDialog pDialog;

    private static String url = "https://api.myjson.com/bins/tyjyz";

    private static final String TAG_HOTEL = "Daftar Harga Kamar Hotel";
    private static final String TAG_ID = "ID";
    private static final String TAG_NAMA = "Nama Hotel";
    private static final String TAG_LOKASI = "Lokasi";
    private static final String TAG_HARGA = "Harga";

    JSONArray hotel = null;

    ArrayList<HashMap<String, String>> hotelList;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel);

        Intent i = getIntent();

        final String namacustomer = i.getStringExtra("nama");
        final String alamatcustomer = i.getStringExtra("alamat");
        final String notelpcustomer = i.getStringExtra("notelp");

        hotelList = new ArrayList<HashMap<String, String>>();

        ListView lv = getListView();

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                String nama = ((TextView) view.findViewById(R.id.nama)).getText().toString();
                String lokasi = ((TextView) view.findViewById(R.id.lokasi)).getText().toString();
                String harga = ((TextView) view.findViewById(R.id.harga)).getText().toString();

                Intent in = new Intent(getApplicationContext(),PesanKamar.class);
                in.putExtra(TAG_NAMA, nama);
                in.putExtra(TAG_LOKASI, lokasi);
                in.putExtra(TAG_HARGA, harga);
                in.putExtra("nama", namacustomer);
                in.putExtra("alamat", alamatcustomer);
                in.putExtra("notelp", notelpcustomer);
                startActivity(in);

            }
        });

        new GetContacts().execute();
    }

    private class GetContacts extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(Hotel.this);
            pDialog.setMessage("Loading");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            ServiceHandler sh = new ServiceHandler();

            String jsonStr = sh.getContents(url);

            Log.d("Response: ", "> " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    hotel = jsonObj.getJSONArray(TAG_HOTEL);

                    for (int i = 0; i < hotel.length(); i++) {
                        JSONObject c = hotel.getJSONObject(i);

                        String id = c.getString(TAG_ID);
                        String nama = c.getString(TAG_NAMA);
                        String lokasi = c.getString(TAG_LOKASI);
                        String harga = c.getString(TAG_HARGA);

                        HashMap<String, String> hotel = new HashMap<String, String>();

                        hotel.put(TAG_ID, id);
                        hotel.put(TAG_NAMA, nama);
                        hotel.put(TAG_LOKASI, lokasi);
                        hotel.put(TAG_HARGA, harga);

                        hotelList.add(hotel);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (pDialog.isShowing())
                pDialog.dismiss();

            ListAdapter adapter = new SimpleAdapter(
                    Hotel.this, hotelList,
                    R.layout.list_item, new String[] {TAG_NAMA, TAG_LOKASI, TAG_HARGA },
                    new int[] {R.id.nama, R.id.lokasi, R.id.harga});

            setListAdapter(adapter);
        }

    }
}
